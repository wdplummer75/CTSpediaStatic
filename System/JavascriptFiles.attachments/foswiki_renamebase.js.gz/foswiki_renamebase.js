function checkAll(e,c){if(void 0!=e){var n;for(n=0;n<e.length;++n)e.elements[n].name.match("referring_topics")&&(e.elements[n].checked=c)}}
