"use strict";var $j=jQuery.noConflict();
